<?php

// каждый параметр может принять число или null
function concatIntegers(?int $a, ?int $b): ?string
{
    // должна вернуться строка или null
    return ($a == null || $b == null) ? null : $a . $b;
}


echo gettype(concatIntegers(10, null));