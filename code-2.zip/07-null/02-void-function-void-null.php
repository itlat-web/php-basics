<?php

// на печать будет выведено NULL
echo gettype(example()); 

function example(): void
{
}
