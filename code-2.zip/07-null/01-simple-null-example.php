<?php

$result = null;

// на печать будет выведено NULL
echo gettype($result); 
