<?php

// проверка, что cookie number_of_visits существует и является число
if (isset($_COOKIE['number_of_visits']) && 
    !is_array($_COOKIE['number_of_visits']) && 
    is_numeric($_COOKIE['number_of_visits'])
) {
    // получение cookie и увеличение его значения на единицу
    $updatedNumberOfVisits = $_COOKIE['number_of_visits'] + 1;
    
    // установление обновленного значения cookie
    setcookie('number_of_visits', $updatedNumberOfVisits, time() + 86400);
    
    // любой вывод на печать должен быть после установки cookie!
    echo 'Количество ваших посещений этой страницы: ' . $updatedNumberOfVisits;
} else {
    // установление изначального значения cookie
    setcookie('number_of_visits', 1, time() + 86400);
    
    echo 'Вы впервые на этой странице';
}
