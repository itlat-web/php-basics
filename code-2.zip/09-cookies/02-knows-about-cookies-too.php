<?php

if (isset($_COOKIE['number_of_visits']) && 
    !is_array($_COOKIE['number_of_visits']) && 
    is_numeric($_COOKIE['number_of_visits'])
) {
    // получение значения cookie
    $numberOfVisits = $_COOKIE['number_of_visits'];
    
    echo 'Я тоже знаю о cookie на другой странице, но менять его не буду - значение этого cookie: ' . $numberOfVisits;
}
