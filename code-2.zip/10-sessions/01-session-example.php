<?php

session_start();

$content = 'Какое-то скрытое содержимое страницы.';

if (isset($_GET['logout'])) {
    // уничтожение данных сессии
    session_destroy();
    
    echo 'Все данные сессии были уничтожены';
} elseif (isset($_POST['password'])) {
    if ($_POST['password'] === 'secret') {
        
        // запись данных в сессию
        $_SESSION['logged_in'] = true;
        
        // покажем скрытое содержимое пользователю!
        echo 
            'Вы успешно зашли в систему!', 
            '<br><br>', 
            $content, 
            '<br><br>',
            'Если хотите выйти - нажмите сюда: <a href="?logout=1">Выйти</a>';
        
    } else {
        echo 'Неверный пароль!';
    }
    
// проверка на то, что человек уже заходил в систему
} elseif (isset($_SESSION['logged_in'])) {
    
    // покажем скрытое содержимое пользователю!
    echo 
        'Вы заходили в систему ранее!', 
        '<br><br>', 
        $content, 
        '<br><br>', 
        'Если хотите выйти - нажмите сюда: <a href="?logout=1">Выйти</a>';
} else {
?>
<form action="" method="POST">
    Введите правильный пароль, чтобы войти в систему: <input type="password" name="password">
    <br><br>
    <button type="submit">Подтвердить</button>
</form>
<?php
}