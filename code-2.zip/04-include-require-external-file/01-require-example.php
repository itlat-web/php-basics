<?php

require 'functions.php';

// функция calcSumWithTax отсутствует в файле index.php, однако эта функция определена в файле functions.php, который был подключен несколькими строчками выше с помощью require 'functions.php';
echo calcSumWithTax(100, 21); 
