<?php

function calcSumWithTax(float $sum, float $taxPercent): float
{
    return $sum + ($sum * $taxPercent / 100);

}
