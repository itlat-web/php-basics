<?php

require 'functions.php';
require 'functions.php'; // ошибка! - попытка повторного объявления функции calcSumWithTax

echo calcSumWithTax(100, 21); 
