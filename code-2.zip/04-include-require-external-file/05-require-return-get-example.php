<?php

$returnedValue = require_once 'return.php';

echo $returnedValue; // на печать будет выведена цифра 5 - т.е. значение полученное из подключенного файла
