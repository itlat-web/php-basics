<?php

$firstNumber = 3;

$secondNumber = 2;

return $firstNumber + $secondNumber; // возвращение данных из глобальной области видимости
