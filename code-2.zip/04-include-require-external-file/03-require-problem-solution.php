<?php

require_once 'functions.php';
require_once 'functions.php'; // ошибки не будет, т.к. файл уже был загружен

echo calcSumWithTax(100, 21); // успешно выведется 121
