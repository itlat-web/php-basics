<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && 
    isset($_FILES['userfile']) &&
    $_FILES['userfile']['error'] === UPLOAD_ERR_OK
) {
    /*
        По ключу userfile массива $_FILES можно получить
        еще один массив, который содержит данные файла
    */
    $file = $_FILES['userfile'];

    echo 'Имя: ', $file['name'], '<br>'; // оригинальное имя 

    echo 'Оригинальный путь: ', $file['full_path'], '<br>'; /* путь к файлу на компьютере, с которого загружен файл */

    echo 'Тип: ', $file['type'], '<br>'; // тип файла

    echo 'Код ошибки: ', $file['error'], '<br>'; // код ошибки (если она произошла)

    echo 'Временный путь: ', $file['tmp_name'], '<br>'; /* путь к файлу во временной директории */

    echo 'Размер: ', $file['size']; // размер файла (байты)
}
?>

<form action="" method="POST" enctype="multipart/form-data">
        File: <input type="file" name="userfile">
        <br><br>
        <button type="submit">Submit</button>
</form>
