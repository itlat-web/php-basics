<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && 
    isset($_FILES['userfile']) &&
    $_FILES['userfile']['error'] === UPLOAD_ERR_OK
) {
    $extension = pathinfo($_FILES['userfile']['name'], PATHINFO_EXTENSION);
    $pathToUpload = './upload/userfile.' . $extension;
    
    // загрузка файла
    $success = move_uploaded_file($_FILES['userfile']['tmp_name'], $pathToUpload);

    if ($success) {
        echo 'Файл был успешно сохранен.';
    } else {
        echo 'При сохранении файла произошла ошибка.';
    }   
}
?>

<form action="" method="POST" enctype="multipart/form-data">
        File: <input type="file" name="userfile">
        <br><br>
        <button type="submit">Submit</button>
</form>
