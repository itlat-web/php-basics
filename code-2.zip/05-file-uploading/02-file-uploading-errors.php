<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && 
    isset($_FILES['userfile'])
) {
     // проверка на то, что ошибок нет
     if ($_FILES['userfile']['error'] === UPLOAD_ERR_OK) {
         // здесь обрабатываем успешно загруженный файл
     } else {     
         // мы находимся здесь, то ошибка уже точно произошла
         switch ($_FILES['userfile']['error']) {
             case UPLOAD_ERR_CANT_WRITE:
                 echo 'Нельзя записать файл на диск.'; break;
             case UPLOAD_ERR_NO_TMP_DIR:
                 echo 'Нет временной директории.'; break;
             case UPLOAD_ERR_NO_FILE:
                 echo 'Файл не был загружен.'; break;
             case UPLOAD_ERR_PARTIAL:
                 echo 'Файл загружен частично.'; break;
             case UPLOAD_ERR_INI_SIZE:
                 echo 'Превышен допустимый размер.'; break;
         } 
     }
}
?>

<form action="" method="POST" enctype="multipart/form-data">
        File: <input type="file" name="userfile">
        <br><br>
        <button type="submit">Submit</button>
</form>
