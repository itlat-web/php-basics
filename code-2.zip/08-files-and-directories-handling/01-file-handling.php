<?php

$filename = 'file-for-file-handling.txt';

// проверка на существование файла или директории
if (file_exists($filename)) {
    echo 'Файл или директория file-for-file-handling.txt существует.', '<br>'; 
}

// проверка на существование файла
if (is_file($filename)) {
    echo 'Файл file-for-file-handling.txt существует.', '<br>';
}

// получение содержимого файла в виде строки
echo 'Содержимое файла: ', file_get_contents($filename), '<br>';

// получение размера файла (в байтах)
echo 'Размер файла в байтах: ', filesize($filename), '<br>';

// получение строк файла в виде массива
echo print_r(file($filename), 1), '<br>';


// копирование файла
copy($filename, 'another-file-for-file-handling.txt');

$anotherFileForFileHandling = 'another-file-for-file-handling.txt';

// запись в файл (файл будет полность перезаписан, если его нет - будет создан)
file_put_contents($anotherFileForFileHandling, 'some text ');

// запись в файл (текст будет добавлен в конец файла)
file_put_contents($anotherFileForFileHandling, 'some another text', FILE_APPEND);

// переименование файла
rename($anotherFileForFileHandling, 'new-name.txt');

// удаление файла (пока закомментируем, чтобы увидеть, что записано в файле new-name.txt)
// unlink('new-name.txt');