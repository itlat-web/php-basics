<?php

$directoryName = 'directory-for-directory-handling';

// проверка на существование директории
if (is_dir($directoryName)) {
    echo 'Директория directory-for-directory-handling существует.', '<br>';
}

// создание директории
mkdir('some-other-directory-name');

// удаление директории (только если директория пустая)
rmdir('some-other-directory-name');

/*
    получение файлов и директорий внутри запрошенной 
    директории в виде массива - в числе прочего содержит
    запрошенную директорию (в виде точки - .), а также
    родительскую директорию (в виде двоеточия - ..)
*/
echo 'Содержимое директории с исполяемым файлом: ' . print_r(scandir('.'), 1), '<br>';

echo '<hr>';

// напечатает все вложенные файлы и директории родительской директории
printDirContent('..');

// функция для чтения всех вложенных файлов и директорий
function printDirContent(string $dirname): void
{
	foreach (scandir($dirname) as $item) {
		if ($item === '.' || $item === '..') {
			continue;
		}
		
          // печатаем найденную директорию или файл
		$path = $dirname . '/' . $item;
		echo $path, '<br>';
		
          // если директория - обходим и ее
		if (is_dir($path)) {
            echo '<blockquote>';
			printDirContent($path);
            echo '</blockquote>';
		}
	}
}
